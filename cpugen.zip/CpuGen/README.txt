CpuGen (TM)	by gferrante@opencores.org

1) Unzip cpugen.zip (ex. in C:\)

2) Run cpugen.exe

3) Look at help and tutorial files (.pdf)

NOTE: need Acrobat Reader (TM)

OS: Microsoft Windows (TM)